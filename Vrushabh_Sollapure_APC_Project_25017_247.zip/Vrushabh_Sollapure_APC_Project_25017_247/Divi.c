#include "apc.h"  


int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    // Initialize result list pointers to NULL (empty)
    *headR = *tailR = NULL;

    // Step 1: Convert both linked lists into integers
    long long num1 = 0, num2 = 0;  // Store the converted integer values
    Dlist *temp;

    // Traverse first list and form the number (e.g., 1→2→3 becomes 123)
    for (temp = *head1; temp != NULL; temp = temp->next)
        num1 = num1 * 10 + temp->data;

    // Traverse second list and form the number (e.g., 4→5 becomes 45)
    for (temp = *head2; temp != NULL; temp = temp->next)
        num2 = num2 * 10 + temp->data;

    // Step 2: Check for division by zero
    if (num2 == 0)
    {
        printf("Error: Division by zero\n");  // Print error message
        return FAILURE;                       // Return failure status
    }

    // Step 3: Perform integer division
    long long q = num1 / num2;  // Compute quotient (integer part only)

    // Step 4: If quotient is 0, insert a single node '0' into result list
    if (q == 0)
    {
        insert_at_last(headR, tailR, 0);
        return SUCCESS;
    }

    // Step 5: Convert quotient (integer) into a doubly linked list
    while (q > 0)
    {
        int digit = q % 10;                   // Extract last digit
        insert_at_first(headR, tailR, digit); // Insert at front to maintain correct order
        q /= 10;                              // Remove last digit
    }

    // Step 6: Return success status
    return SUCCESS;
}
