#include "apc.h"  


void insert_at_last(Dlist **head, Dlist **tail, int data)
{
    // Step 1: Dynamically allocate memory for the new node
    Dlist *new = malloc(sizeof(Dlist));

    // Step 2: Initialize the new node with data and NULL links
    new->prev = NULL;  // Will be updated if list is not empty
    new->data = data;  // Store given data
    new->next = NULL;  // No next node because it will be inserted at the end

    // Step 3: If the list is empty
    if (*head == NULL && *tail == NULL)
    {
        // Both head and tail will point to this new node
        *head = new;
        *tail = new;
    }
    else
    {
        // Step 4: If the list is not empty, link the new node at the end
        (*tail)->next = new;  // Current tail's next points to the new node
        new->prev = *tail;    // New node's prev points to the current tail
        *tail = new;          // Update tail pointer to the new node
    }
}
