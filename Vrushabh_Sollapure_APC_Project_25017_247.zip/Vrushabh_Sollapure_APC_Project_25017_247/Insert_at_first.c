#include "apc.h"  


void insert_at_first(Dlist **head, Dlist **tail, int data)
{
    // Step 1: Dynamically allocate memory for the new node
    Dlist *new = malloc(sizeof(Dlist));

    // Step 2: Initialize the new node
    new->prev = NULL;   // No previous node since it's inserted at the beginning
    new->data = data;   // Store given data in the node
    new->next = *head;  // Point new node's 'next' to the current head

    // Step 3: Check if the list is empty
    if (*head == NULL && *tail == NULL)
    {
        // If empty, both head and tail point to the new node
        *head = new;
        *tail = new;
    }
    else
    {
        // If list is not empty, link the current head back to the new node
        (*head)->prev = new;

        // Update head pointer to the new node (new node becomes the first node)
        *head = new;
    }
}
