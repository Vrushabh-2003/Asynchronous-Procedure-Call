#include "apc.h"


int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2,
                Dlist **headR, Dlist **tailR)
{
    int negResult = 0; // To store if result should be negative

    // Compare both numbers to know which is larger
    if(compare_lists(*head1, *head2) < 0)  // If head1 < head2
    {
        // Swap the lists so subtraction happens as (bigger - smaller)
        Dlist *tH = *head1, *tT = *tail1;
        *head1 = *head2; *tail1 = *tail2;
        *head2 = tH; *tail2 = tT;

        negResult = 1;  // Final result will be negative
    }

    Dlist *temp1 = *tail1;  // Start from last node (least significant digit)
    Dlist *temp2 = *tail2;
    int borrow = 0;         // Initialize borrow as 0

    *headR = *tailR = NULL; // Initialize result list as empty

    // Perform digit-by-digit subtraction
    while(temp1 != NULL || temp2 != NULL)
    {
        int sub = 0;

        // Take digit from first number if available
        if(temp1 != NULL)
        {
            sub += temp1->data;
            temp1 = temp1->prev;
        }

        // Subtract digit of second number if available
        if(temp2 != NULL)
        {
            sub -= temp2->data;
            temp2 = temp2->prev;
        }

        // Subtract any previous borrow
        sub -= borrow;

        // If subtraction goes negative → borrow from next higher digit
        if(sub < 0)
        {
            sub += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        // Insert current digit at the beginning of result list
        insert_at_first(headR, tailR, sub);
    }

    // Remove leading zeros (for example, 0021 → 21)
    while(*headR != NULL && (*headR)->data == 0 && (*headR)->next != NULL)
    {
        Dlist *temp = *headR;
        *headR = (*headR)->next;
        (*headR)->prev = NULL;
        free(temp);
    }

    return negResult; // Return whether result is negative (1) or positive (0)
}
