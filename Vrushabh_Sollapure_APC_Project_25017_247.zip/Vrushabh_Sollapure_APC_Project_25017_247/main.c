/*
NAME : Vrushabh Sollapure
DATE : 02/11/2025
DES  : APC Project (Arbitrary Precision Calculator)

Sample input  : ./a.out 2356 + 2484
Sample output : RESULT:4840

Sample input  : ./a.out -2356 + 2484
Sample output : RESULT:128

Sample input  : ./a.out 5000 - 3000
Sample output : RESULT:2000

Sample input  : ./a.out 3568 - 5659
Sample output : RESULT:-2091

Sample input  : ./a.out 1234 * 78
Sample output : RESULT:96252

Sample input  : ./a.out -1234 * 78
Sample output : RESULT:-96252

Sample input  : ./a.out 1000 / 25
Sample output : RESULT:40

Sample input  : ./a.out -9835 / 25
Sample output : RESULT:-393
*/

#include "apc.h"  

int main(int argc, char *argv[])
{
    // Step 1: Validate argument count
    if (argc != 4)
    {
        return FAILURE; // Return failure if wrong number of arguments
    }

    // Step 2: Validate argument format (operands and operator)
    if (validate(argv) == FAILURE)
    {
        printf("INVALID ARGUMENTS\n");
        printf("Operands should be numbers and operator must be one of +, -, *, /\n");
        return FAILURE;
    }

    // Step 3: Initialize all doubly linked lists
    Dlist *head1 = NULL, *tail1 = NULL; // For first number
    Dlist *head2 = NULL, *tail2 = NULL; // For second number
    Dlist *headR = NULL, *tailR = NULL; // For result

    int neg1 = 0, neg2 = 0; // Flags for negative numbers

    // Step 4: Handle sign for first operand
    char *num1 = argv[1];
    if (num1[0] == '-')  // Check if first number is negative
    {
        neg1 = 1;
        num1++;        
    }

    // Step 5: Handle sign for second operand
    char *num2 = argv[3];
    if (num2[0] == '-')  // Check if second number is negative
    {
        neg2 = 1;
        num2++;         
    }

    // Step 6: Extract the operator (+, -, *, /)
    char operator = argv[2][0];

    // Step 7: Perform operation based on operator
    switch (operator)
    {
        case '+':
            // Convert both operands into linked lists
            digit_to_list(&head1, &tail1, &head2, &tail2, num1, num2);

            print(head1, tail1);
            print(head2, tail2);

            if (neg1 == neg2)  // Same signs → perform addition
            {
                addition(&head1, &tail1, &head2, &tail2, &headR, &tailR);

                // Add negative sign node at front if result is non-zero
                if (neg1 && headR->data != 0)
                    insert_at_first(&headR, &tailR, -1);
            }
            else  // Different signs → perform subtraction
            {
                int negResult = subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR);
                if (neg1) negResult = !negResult; // Adjust sign if first operand was negative
                if (negResult && headR->data != 0)
                    insert_at_first(&headR, &tailR, -1);
            }

            printf("RESULT:");
            print(headR, tailR);
            break;

        case '-':
            // Convert both operands into linked lists
            digit_to_list(&head1, &tail1, &head2, &tail2, num1, num2);

            print(head1, tail1);
            print(head2, tail2);

            if (neg1 != neg2)  // Different signs → perform addition
            {
                addition(&head1, &tail1, &head2, &tail2, &headR, &tailR);
                if (neg1 && headR->data != 0)
                    insert_at_first(&headR, &tailR, -1);
            }
            else  // Same signs → perform subtraction
            {
                int negResult = subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR);
                if (neg1) negResult = !negResult; // Adjust final sign
                if (negResult && headR->data != 0)
                    insert_at_first(&headR, &tailR, -1);
            }

            printf("RESULT:");
            print(headR, tailR);
            break;

        case '*':
            // Convert both operands into linked lists
            digit_to_list(&head1, &tail1, &head2, &tail2, num1, num2);

            print(head1, tail1);
            print(head2, tail2);

            // Perform multiplication
            multiplication(&head1, &tail1, &head2, &tail2, &headR, &tailR);

            // Handle sign: one negative → negative result
            if ((neg1 && !neg2) || (!neg1 && neg2))
                if (headR->data != 0)
                    insert_at_first(&headR, &tailR, -1);

            printf("RESULT:");
            print(headR, tailR);
            break;

        case '/':
            // Convert both operands into linked lists
            digit_to_list(&head1, &tail1, &head2, &tail2, num1, num2);

            print(head1, tail1);
            print(head2, tail2);

            // Perform division and handle divide-by-zero
            if (division(&head1, &tail1, &head2, &tail2, &headR, &tailR) == FAILURE)
                return FAILURE;

            // Remove unnecessary leading zeros (e.g., 00040 → 40)
            while (headR && headR->data == 0 && headR->next != NULL)
            {
                Dlist *del = headR;
                headR = headR->next;
                headR->prev = NULL;
                free(del);
            }

            // Handle negative result (only if result not zero)
            if ((neg1 && !neg2) || (!neg1 && neg2))
            {
                if (!(headR->data == 0 && headR->next == NULL))
                    insert_at_first(&headR, &tailR, -1);
            }

            printf("RESULT:");
            print(headR, tailR);
            break;

        default:
            printf("Invalid Input :-( Try again...\n");
    }

    return 0;
}
