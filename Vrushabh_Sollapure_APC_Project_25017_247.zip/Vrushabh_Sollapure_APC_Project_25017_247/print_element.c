#include "apc.h"

void print(Dlist *head, Dlist *tail)
{
    Dlist *temp = head;           // Start from the head of the list
    int negative = 0;             // Flag to check if number is negative

    // Check if the first node is a sentinel for negative numbers (-1)
    if(temp != NULL && temp->data == -1)
    {
        negative = 1;             // Mark the number as negative
        temp = temp->next;        // Skip the sentinel node
    }

    // Print prefix depending on sign
    if(negative)
        printf("Head->-");        // Print minus sign for negative number
    else
        printf("Head->");         // Print normal head start

    // Traverse and print each digit node
    while(temp != NULL)
    {
        printf("%d", temp->data); // Print current digit
        temp = temp->next;        // Move to next node
    }

    // End of list
    printf("<-tail\n");
}
