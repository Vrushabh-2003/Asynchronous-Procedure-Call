#include "apc.h"

void digit_to_list(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, char *num1, char *num2)
{
    int i; 
    for (i = 0; num1[i] != '\0'; i++)   // Traverse the string until null character
    {
        int digit = num1[i] - '0';      // Convert ASCII character to integer digit
                                        // e.g., '5' → 53 (ASCII) → 53 - 48 = 5
        insert_at_last(head1, tail1, digit);  // Insert digit at the end of the first linked list
    }

    for (i = 0; num2[i] != '\0'; i++)   // Traverse the string until null character
    {
        int digit = num2[i] - '0';      // Convert ASCII character to integer digit
        insert_at_last(head2, tail2, digit);  // Insert digit at the end of the second linked list
    }
}
