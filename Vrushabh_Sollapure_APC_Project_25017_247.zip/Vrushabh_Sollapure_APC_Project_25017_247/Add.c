#include "apc.h"  

// Function to perform addition of two numbers represented as doubly linked lists
int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    // Initialize temp pointers to traverse both linked lists from the end (least significant digit)
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    int carry = 0;  // Variable to store carry during addition
    int res = 0;    // Variable to store result of digit addition

    
    while (temp1 != NULL || temp2 != NULL)
    {
        // Case 1: both lists have remaining digits
        if (temp1 != NULL && temp2 != NULL)
        {
            res = temp1->data + temp2->data + carry;  // Add digits from both lists + carry
            temp1 = temp1->prev;  // Move to previous digit in Dlist1
            temp2 = temp2->prev;  // Move to previous digit in Dlist2
        }
        // Case 2: Dlist1 is empty, Dlist2 still has digits
        else if (temp1 == NULL && temp2 != NULL)
        {
            res = temp2->data + carry;  // Add digit from list2 + carry
            temp2 = temp2->prev;        // Move to previous digit in list2
        }
        // Case 3: list2 is empty, list1 still has digits
        else if (temp2 == NULL && temp1 != NULL)
        {
            res = temp1->data + carry;  // Add digit from list1 + carry
            temp1 = temp1->prev;        // Move to previous digit in list1
        }

        // Update carry and remainder after each addition
        carry = res / 10;  // Extract carry (e.g., 15 → carry = 1)
        res = res % 10;    // Keep only the last digit (e.g., 15 → res = 5)

        // Insert the result digit at the front of the result list (most significant side)
        insert_at_first(headR, tailR, res);
    }

    // If a carry is left after the last addition, insert it at the beginning
    if (carry > 0)
    {
        insert_at_first(headR, tailR, carry);
    }

    return SUCCESS;  // Return success status (defined in apc.h)
}
