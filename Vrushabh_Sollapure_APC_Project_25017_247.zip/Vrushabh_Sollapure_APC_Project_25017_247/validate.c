#include "apc.h"

int validate(char *argv[])
{
    int i;

    i = 0;
    if(argv[1][0] == '-') i = 1;  // If number is negative, skip the minus sign

    while(argv[1][i] != '\0')     // Loop through each character
    {
        if(!isdigit(argv[1][i]))  // If any non-digit character is found
            return FAILURE;       // Invalid input
        i++;
    }

    i = 0;
    if(argv[3][0] == '-') i = 1;  // Skip minus if negative number

    while(argv[3][i] != '\0')     // Loop through each character
    {
        if(!isdigit(argv[3][i]))  // If non-digit found
            return FAILURE;       // Invalid input
        i++;
    }

    char op = argv[2][0];         // Extract operator
    if(op != '+' && op != '-' && op != '*' && op != '/')  // Only allow + - * /
        return FAILURE;           // Invalid operator

    return SUCCESS;               // All inputs are valid
}
