#ifndef APC_H
#define APC_H

#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE -1


typedef struct node
{
	struct node *prev;
	int data;
	struct node *next;
}Dlist;

/* Include the prototypes here */

/*store the operands into the list */
void digit_to_list(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, char *num1, char *num2);

/*Addition */
int addition(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR);

/*subtraction*/
int subtraction(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR);

/*Multiplication*/
int multiplication(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR);

/*Division */
int division(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR);

void insert_at_first(Dlist **head,Dlist **tail,int data);

void insert_at_last(Dlist **head,Dlist **tail,int data);

void print(Dlist *head,Dlist *tail);

int validate(char *argv[]);

int compare_lists(Dlist *head1, Dlist *head2);



#endif
