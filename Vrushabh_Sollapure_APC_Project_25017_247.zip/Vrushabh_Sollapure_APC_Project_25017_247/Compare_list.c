#include "apc.h"  

int compare_lists(Dlist *head1, Dlist *head2)
{
    // Step 1: Initialize counters to count number of digits in each list
    int len1 = 0, len2 = 0;
    Dlist *temp;

    // Step 2: Count number of nodes (digits) in first list
    for (temp = head1; temp != NULL; temp = temp->next)
        len1++;

    // Step 3: Count number of nodes (digits) in second list
    for (temp = head2; temp != NULL; temp = temp->next)
        len2++;

    // Step 4: If first number has more digits, it's larger
    if (len1 > len2)
        return 1;   // head1 > head2

    // Step 5: If second number has more digits, it's larger
    if (len2 > len1)
        return -1;  // head1 < head2

    // Step 6: If both have same number of digits, compare digit-by-digit
    Dlist *t1 = head1;
    Dlist *t2 = head2;

    while (t1 && t2)
    {
        // Compare current digits from most significant to least
        if (t1->data > t2->data)
            return 1;   // First number is greater
        if (t1->data < t2->data)
            return -1;  // Second number is greater

        // Move both pointers forward
        t1 = t1->next;
        t2 = t2->next;
    }

    // Step 7: If loop completes without returning, both numbers are equal
    return 0; // Equal numbers
}
