#include "apc.h"

int multiplication(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **headR, Dlist **tailR)
{
    Dlist *temp2 = *tail2;                // Start from the last digit of 2nd number
    Dlist *headR2 = NULL, *tailR2 = NULL; // Temporary result list for addition
    int count = 0;                        // To track zero shifts (10^count)

    *headR = *tailR = NULL; // Initialize final result as empty

    while(temp2 != NULL) // Loop through each digit of 2nd number
    {
        Dlist *temp1 = *tail1;           // Start from last digit of 1st number
        Dlist *headR1 = NULL, *tailR1 = NULL; // Store partial product
        int carry = 0;                   // Initialize carry

        // Multiply each digit of first number with current digit of second number
        while(temp1 != NULL)
        {
            int res = temp1->data * temp2->data + carry; // Multiply + add carry
            carry = res / 10;                            // Update carry
            int dig = res % 10;                          // Extract last digit

            insert_at_first(&headR1, &tailR1, dig);      // Insert digit at front
            temp1 = temp1->prev;                         // Move to previous node
        }

        if(carry)                                        // If carry remains
            insert_at_first(&headR1, &tailR1, carry);    // Insert carry at front

        // Add zeros at end for positional shift (like multiplying by 10^count)
        for(int i = 0; i < count; i++)
           insert_at_last(&headR1, &tailR1, 0);

        // If first partial product → directly assign to result
        if(*headR == NULL)
        {
            *headR = headR1;
            *tailR = tailR1;
        }
        else
        {
            // Add new partial product to existing result
            addition(headR, tailR, &headR1, &tailR1, &headR2, &tailR2);

            *headR = headR2;   // Update head and tail to new result
            *tailR = tailR2;
            headR2 = tailR2 = NULL; // Reset temporary pointers
        }

        temp2 = temp2->prev;   // Move to previous digit of 2nd number
        count++;               // Increase zero shift
    }

    return SUCCESS; // Indicate multiplication completed
}
